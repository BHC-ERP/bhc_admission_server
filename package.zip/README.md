# bhc_admission_server
Admission System backend server - created in nodejs with express 
